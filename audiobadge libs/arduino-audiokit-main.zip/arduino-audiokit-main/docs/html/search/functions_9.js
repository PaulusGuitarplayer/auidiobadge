var searchData=
[
  ['volume_87',['volume',['../classaudiokit_1_1_audio_kit.html#ad236d314493b0e5c0bb3b05d0109238e',1,'audiokit::AudioKit']]]
];
