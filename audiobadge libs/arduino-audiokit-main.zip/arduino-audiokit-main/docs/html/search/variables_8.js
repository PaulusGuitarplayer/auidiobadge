var searchData=
[
  ['master_5fslave_5fmode_286',['master_slave_mode',['../struct_audio_kit_config.html#add6c0604564d301e8582d8fc5a18d815',1,'AudioKitConfig']]],
  ['miso_5fio_5fnum_287',['miso_io_num',['../audio__gpio_8h.html#a68f9b7c3c9f3b359de590fd8b70d0824',1,'spi_bus_config_t']]],
  ['mode_288',['mode',['../audio__hal_8h.html#a730344407f659f0d733401a8c98b01de',1,'audio_hal_codec_i2s_iface_t::mode()'],['../audio__gpio_8h.html#aff5e0ac442828c29d581b8b9d9f4f194',1,'i2c_config_t::mode()'],['../audio__gpio_8h.html#a7f8f7be11a8edef4f9d7b14e66e6f081',1,'gpio_config_t::mode()']]],
  ['mosi_5fio_5fnum_289',['mosi_io_num',['../audio__gpio_8h.html#acb6c97389e9618d4680c5784999ff952',1,'spi_bus_config_t']]]
];
