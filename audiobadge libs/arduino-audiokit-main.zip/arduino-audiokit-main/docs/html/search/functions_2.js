var searchData=
[
  ['config_58',['config',['../classaudiokit_1_1_audio_kit.html#aa9afa7578612350fa4f880ec7bff826e',1,'audiokit::AudioKit']]]
];
