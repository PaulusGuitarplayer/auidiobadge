var searchData=
[
  ['samplerate_79',['sampleRate',['../structaudiokit_1_1_audio_kit_config.html#ab3e8df85a89b5f55eb5e6dcb5accf690',1,'audiokit::AudioKitConfig']]],
  ['setactive_80',['setActive',['../classaudiokit_1_1_audio_kit.html#a50906c46b29710805167bda317233623',1,'audiokit::AudioKit']]],
  ['setmute_81',['setMute',['../classaudiokit_1_1_audio_kit.html#aaa16731bd7186b72525d25447e08a134',1,'audiokit::AudioKit']]],
  ['setsamplerate_82',['setSampleRate',['../classaudiokit_1_1_audio_kit.html#a9d8f1f16e792c3baaa99405437c97bbb',1,'audiokit::AudioKit']]],
  ['setspeakeractive_83',['setSpeakerActive',['../classaudiokit_1_1_audio_kit.html#abd0d962ee607bda3eaea1649a23a2483',1,'audiokit::AudioKit']]],
  ['setupheadphonedetection_84',['setupHeadphoneDetection',['../classaudiokit_1_1_audio_kit.html#a58c06483a574a87204e2af9d590addf0',1,'audiokit::AudioKit']]],
  ['setupspi_85',['setupSPI',['../classaudiokit_1_1_audio_kit.html#a21da04e0294818fcbb15802b1671157e',1,'audiokit::AudioKit']]],
  ['setvolume_86',['setVolume',['../classaudiokit_1_1_audio_kit.html#a06815b05d142e3c1147e94e05a331c2a',1,'audiokit::AudioKit']]]
];
