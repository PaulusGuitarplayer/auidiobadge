var searchData=
[
  ['begin_56',['begin',['../classaudiokit_1_1_audio_kit.html#a5112da6adf0e8b9b73bfadc293ff2a11',1,'audiokit::AudioKit']]],
  ['bitspersample_57',['bitsPerSample',['../structaudiokit_1_1_audio_kit_config.html#aaaef96c0f87b147eda7542638fbcdc36',1,'audiokit::AudioKitConfig']]]
];
