var searchData=
[
  ['actionheadphonedetection_55',['actionHeadphoneDetection',['../classaudiokit_1_1_audio_kit.html#a06a8ffc60859dab237371bb5f3cf63b0',1,'audiokit::AudioKit']]]
];
