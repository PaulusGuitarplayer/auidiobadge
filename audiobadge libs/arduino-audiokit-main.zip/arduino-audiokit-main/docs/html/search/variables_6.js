var searchData=
[
  ['pins_95',['pins',['../structaudiokit_1_1_audio_kit_config.html#a2c1e8063d82aea65aab676f2bb9e7133',1,'audiokit::AudioKitConfig']]]
];
