var searchData=
[
  ['audiokit_5fboard_2eh_53',['audiokit_board.h',['../audiokit__board_8h.html',1,'']]],
  ['audiokitsettings_2eh_54',['AudioKitSettings.h',['../_audio_kit_settings_8h.html',1,'']]]
];
