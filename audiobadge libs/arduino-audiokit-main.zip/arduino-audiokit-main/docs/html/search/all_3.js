var searchData=
[
  ['dac_5foutput_14',['dac_output',['../structaudiokit_1_1_audio_kit_config.html#a9dd9f607f10f3e7f6cdb9121639ba452',1,'audiokit::AudioKitConfig']]],
  ['defaultconfig_15',['defaultConfig',['../classaudiokit_1_1_audio_kit.html#a9873022509d64892a7a30ba5abe3382d',1,'audiokit::AudioKit']]],
  ['driver_16',['driver',['../structaudiokit_1_1_audio_kit_config.html#a23847eaad7a8582ef6895c5d444a7f9a',1,'audiokit::AudioKitConfig']]]
];
