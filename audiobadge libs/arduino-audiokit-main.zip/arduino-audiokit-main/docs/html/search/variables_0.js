var searchData=
[
  ['adc_5finput_88',['adc_input',['../structaudiokit_1_1_audio_kit_config.html#a1f05c59296cca5f9616053f53400fd37',1,'audiokit::AudioKitConfig']]]
];
